export const config = {
  apiKey: "AIzaSyACSUS80qgqEzuQQmo_hMJbEJDwqsIf1ns",
  authDomain: "businessaide-fab48.firebaseapp.com",
  projectId: "businessaide-fab48",
  storageBucket: "businessaide-fab48.appspot.com",
  messagingSenderId: "440207297304",
  appId: "1:440207297304:web:1ee77efcf3f79a1e09ec6d",
  measurementId: "G-V4KJ4B5E32",
};
